import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit {

  movies:any;
  movieById:any;
  constructor(private service:MovieService){}

  ngOnInit(): void {
      this.movies = this.service.getMovies().subscribe((data)=>this.movies=data);
  }

}
