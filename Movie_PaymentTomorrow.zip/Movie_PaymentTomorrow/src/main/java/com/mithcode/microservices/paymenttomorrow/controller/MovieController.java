package com.mithcode.microservices.paymenttomorrow.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mithcode.microservices.paymenttomorrow.entity.Movie;
import com.mithcode.microservices.paymenttomorrow.service.MovieService;

@RestController
@RequestMapping("/PaymentTomorrow")
@CrossOrigin(origins="*")
public class MovieController {

	@Autowired
	private MovieService movieService;

	@GetMapping("/getMovies")
	public List<Movie> getMovies() {
		return movieService.getAllMovies();
	}
	
	@PostMapping("/addMovie")
	public Movie addMovie(@RequestBody Movie movie) {
		return movieService.createMovie(movie);
	}

	@PostMapping("/addMovies")
	public List<Movie> addMovies(@RequestBody List<Movie> movies) {
		return movieService.createMovies(movies);
	}

	@GetMapping("/getMovieById/{id}")
	public Movie getMovieById(@PathVariable int id) {
		return movieService.getMovieById(id);
	}

	@PutMapping("/updateMovie")
	public Movie updateMovie(@RequestBody Movie movie) {
		return movieService.updateMovie(movie);
	}

	@DeleteMapping("/deleteMovieById/{id}")
	public String deleteMovieById(@PathVariable int id) {
		return movieService.deleteMovieById(id);
	}
}
