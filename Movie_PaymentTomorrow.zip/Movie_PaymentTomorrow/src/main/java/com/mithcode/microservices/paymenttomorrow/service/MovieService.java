package com.mithcode.microservices.paymenttomorrow.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mithcode.microservices.paymenttomorrow.entity.Movie;
import com.mithcode.microservices.paymenttomorrow.repo.MovieRepository;

@Service
public class MovieService {
	
	@Autowired
	private MovieRepository movieRepository;
		
	public Movie createMovie(Movie movie) {
		return movieRepository.save(movie);
		
	}

	public List<Movie> createMovies(List<Movie> movies) {
		return movieRepository.saveAll(movies);
		
	}
	
	public Movie getMovieById(int id) {
		return movieRepository.findById(id).orElse(null);
		
	}
	
	public List<Movie> getAllMovies() {
		return movieRepository.findAll();
		
	}

	public Movie updateMovie(Movie movie) {
	
		Optional<Movie> optionalMovie = movieRepository.findById(movie.getId());
		Movie oldMovie = null;
		if(optionalMovie.isPresent()) {
			oldMovie = optionalMovie.get();
			oldMovie.setId(movie.getId());
			oldMovie.setTitle(movie.getTitle());
			oldMovie.setDirector(movie.getDirector());
			movieRepository.save(oldMovie);
		} else {
			return new Movie();
		}
		
		return oldMovie;
	}
	
	public String deleteMovieById(int id) {
		movieRepository.deleteById(id);
		return "Movie got deleted successfully";
	}
	
}
