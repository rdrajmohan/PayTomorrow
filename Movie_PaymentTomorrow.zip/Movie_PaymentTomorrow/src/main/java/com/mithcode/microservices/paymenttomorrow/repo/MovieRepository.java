package com.mithcode.microservices.paymenttomorrow.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mithcode.microservices.paymenttomorrow.entity.Movie;

public interface MovieRepository extends JpaRepository<Movie, Integer> {

}
